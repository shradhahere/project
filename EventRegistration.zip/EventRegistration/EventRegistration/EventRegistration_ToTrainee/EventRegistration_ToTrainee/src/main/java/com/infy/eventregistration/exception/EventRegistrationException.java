package com.infy.eventregistration.exception;

public class EventRegistrationException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public EventRegistrationException(String message) {
		super(message);
	}
}
