package com.infy.eventregistration.dto;

import java.time.LocalDate;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Pattern;

public class ParticipantDTO {

	private Integer participantId;
	
	@NotNull(message = "{participant.name.notpresent}")
    @Pattern(regexp="[A-Z][a-z]*( [A-Z][a-z]*)*", message="{participant.name.invalid}")
	private String name;
	
	@NotNull(message="{participant.emailid.notpresent}")
	@NotBlank(message="{participant.emailid.notpresent}")
	@Pattern(regexp="[A-Za-z0-9]+(@infy.com)",message = "{participant.emailid.invalid}")
	private String emailId;
	
	@NotNull(message="{participant.gender.notpresent}")
	@Pattern(regexp="(Female|Male|Other)",message= "{participant.gender.invalid}")
	private String gender;
	
	@NotNull(message="{participant.registrationdate.notpresent}")
	@PastOrPresent(message="{participant.registrationdate.invalid}")
	private LocalDate registrationDate;
	
	@NotNull
	@Valid
	private EventDTO eventDTO;

	public Integer getParticipantId() {
		return participantId;
	}

	public void setParticipantId(Integer participantId) {
		this.participantId = participantId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public LocalDate getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(LocalDate registrationDate) {
		this.registrationDate = registrationDate;
	}

	public EventDTO getEventDTO() {
		return eventDTO;
	}

	public void setEventDTO(EventDTO event) {
		this.eventDTO = event;
	}

}
