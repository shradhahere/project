package com.infy.eventregistration.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.infy.eventregistration.entity.Event;
import com.infy.eventregistration.entity.Participant;



public interface ParticipantRepository extends CrudRepository<Participant, Integer>{
	// your code goes here
	List<Participant> findByEventVenue(String venue);
	List<Participant> findByEvent(Event event);
}
