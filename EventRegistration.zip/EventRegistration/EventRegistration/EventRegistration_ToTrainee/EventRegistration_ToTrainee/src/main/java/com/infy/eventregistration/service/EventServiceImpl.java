package com.infy.eventregistration.service;

import java.util.ArrayList;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.eventregistration.dto.EventDTO;
import com.infy.eventregistration.dto.ParticipantDTO;
import com.infy.eventregistration.entity.Event;
import com.infy.eventregistration.entity.Participant;
import com.infy.eventregistration.exception.EventRegistrationException;
import com.infy.eventregistration.repository.EventRepository;
import com.infy.eventregistration.repository.ParticipantRepository;

@Service(value="eventService")
@Transactional
public class EventServiceImpl implements EventService {
	@Autowired
	private EventRepository eventRepository;
	@Autowired
	private ParticipantRepository participantRepository;

	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@Override
	public Integer registerParticipant(ParticipantDTO participantDTO) throws EventRegistrationException {
		// your code goes here
		Event event= eventRepository.findByName(participantDTO.getEventDTO().getName());
	    
		if(event==null)
		{
			throw new EventRegistrationException("Service.EVENT_UNAVAILABLE");
		}
		List<Participant> list=participantRepository.findByEvent(event);
		if(list.size()>=event.getMaxCount())
		{
			throw new EventRegistrationException("Service.REGISTRATION_CLOSED");
		}
		if(participantDTO.getRegistrationDate().isAfter(event.getEventDate().minusDays(3)))
		{
			throw new EventRegistrationException("Service.REGISTRATION_CLOSED");
		}
		Participant participant=new Participant();
		participant.setEmailId(participantDTO.getEmailId());
		participant.setEvent(event);
		participant.setGender(participantDTO.getGender());
		participant.setName(participantDTO.getName());
		participant.setParticipantId(participantDTO.getParticipantId());
		participant.setRegistrationDate(participantDTO.getRegistrationDate());
		Participant newParticipant=participantRepository.save(participant);
		return newParticipant.getParticipantId();
	}
	
	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@Override
	public List<ParticipantDTO> getParticipantsByEventVenue(String venue) throws EventRegistrationException {
		// your code goes here
		
		List<Participant> list=participantRepository.findByEventVenue(venue);
		if(list.isEmpty())
		{
			throw new EventRegistrationException("EventService.PARTICIPANTS_UNAVAILABLE");
		}
		List<ParticipantDTO> listDTO=new ArrayList<>();
				for(Participant part:list)
				{
					Event event=part.getEvent();
					EventDTO eDTO=new EventDTO();
					eDTO.setEventDate(event.getEventDate());
					eDTO.setEventId(event.getEventId());
					eDTO.setMaxCount(event.getMaxCount());
					eDTO.setName(event.getName());
					eDTO.setVenue(event.getVenue());
					
					ParticipantDTO pDTO=new ParticipantDTO();
					pDTO.setEventDTO(eDTO);
					pDTO.setParticipantId(part.getParticipantId());
					pDTO.setEmailId(part.getEmailId());
					pDTO.setGender(part.getGender());
					pDTO.setName(part.getName());
					pDTO.setRegistrationDate(part.getRegistrationDate());
//					List<ParticipantDTO> listpart=
//					list.sort(Collections.reverseOrder());
					listDTO.add(pDTO);
				}
		return listDTO;
	}
}
