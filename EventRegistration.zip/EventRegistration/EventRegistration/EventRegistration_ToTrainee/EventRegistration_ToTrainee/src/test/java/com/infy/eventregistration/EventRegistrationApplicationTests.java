package com.infy.eventregistration;

//import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

//import com.infy.eventregistration.dto.EventDTO;
import com.infy.eventregistration.dto.ParticipantDTO;
//import com.infy.eventregistration.entity.Event;
import com.infy.eventregistration.entity.Participant;
import com.infy.eventregistration.exception.EventRegistrationException;
import com.infy.eventregistration.repository.EventRepository;
import com.infy.eventregistration.repository.ParticipantRepository;
import com.infy.eventregistration.service.EventService;
import com.infy.eventregistration.service.EventServiceImpl;
@SpringBootTest
public class EventRegistrationApplicationTests {
	@Mock
	private EventRepository eventRepository;
	@Mock
	private ParticipantRepository participantRepository;
	@InjectMocks
	private EventService eventService = new EventServiceImpl();
	
	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@Test
	public void getParticipantsByEventVenueNoParticipantsFoundTest() {
//		Event event=new Event();
//		event.setEventId(1);
//		event.setEventDate(LocalDate.of(2020,2,4));
//		event.setMaxCount(100);
//		event.setName("Quiz");
//		event.setVenue("A2-Hall");
//		
//		EventDTO eventDTO=new EventDTO();
//		eventDTO.setEventId(1);
		String name="A2-Hall";
		List<Participant> list=new ArrayList<>();
		Mockito.when(participantRepository.findByEventVenue(Mockito.anyString())).thenReturn(list);
		EventRegistrationException exp=Assertions.assertThrows(EventRegistrationException.class, ()-> eventService.getParticipantsByEventVenue(name));
		Assertions.assertEquals("Service.PARTICIPANTS_UNAVAILABLE", exp.getMessage());
		// your code goes here
	}
	
	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@Test
	public void registerParticipantNoEventFoundTest() {
		// your code goes here
//		Event event=new Event();
//		event.setEventId(1);
//		event.setMaxCount(100);
//		event.setName("Quiz");
//		event.setVenue("A2-Hall");
		
//		EventDTO eventDTO=new EventDTO();
//		eventDTO.setEventId(1);
		
		ParticipantDTO participant=new ParticipantDTO();
//		participant.setEmailId("JohnnyWalker@infy.com");
//		participant.setGender("MALE");
//		participant.setEventDTO(eventDTO);
		participant.setName("Johnny");
//		participant.setParticipantId(123);
		Mockito.when(eventRepository.findByName(Mockito.anyString())).thenReturn(null);
		EventRegistrationException exp=Assertions.assertThrows(EventRegistrationException.class, ()-> eventService.registerParticipant(participant));
		Assertions.assertEquals("Service.EVENT_UNAVAILABLE", exp.getMessage());
		
	}
}
